/*
	Enables polymorphism for a uniform callback method
	after the simulation ends.
	Developed for the University of Glasgow
	Advanced Programming exercise spring 2018.
	@author Nicholas Ferrara
*/

public abstract class Simulation
{
	public void completed () {}
}
