/**
 * Programming AE2
 * Creates and shows the cipher GUI
 */
public class AssEx2
{
	/**
	 * The main method
	 * @param args the arguments
	 */
	public static void main(String [] args)
	{
		CipherGUI CipherGUI = new CipherGUI();
		CipherGUI.setVisible(true);
	}
}
