/**
 * The main class
 * @author Nicholas Ferrara
 * Completes Programming Assessed Exercise 3
 */

public class AssEx3 {
	/**
	 * The main method
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SportsCentreGUI display = new SportsCentreGUI();
		display.setVisible(true);
	}
}
